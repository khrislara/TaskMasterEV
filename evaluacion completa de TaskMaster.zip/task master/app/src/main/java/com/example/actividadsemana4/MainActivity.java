package com.example.actividadsemana4;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // UI Elements
    private TextView tvTitle, tvCardTitle, tvCardContent;
    private Button btnSubmitTask;
    private ImageView imageViewHeader;
    private CheckBox cbTaskCompleted;
    private RadioGroup rgTaskType;
    private ProgressBar progressBarTaskProgress;
    private RatingBar ratingBarTaskPriority;
    private Spinner spinnerTaskCategories;
    private CardView cardViewInfo;
    private TableLayout tableLayoutSummary;
    private RecyclerView recyclerViewTasks;

    // RecyclerView Adapter
    private TaskAdapter taskAdapter;
    private ArrayList<TaskItem> tasksListData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupTaskSpinner();
        setupRecyclerViewTasks();
        setupListeners();
    }

    // Inicializar vistas
    private void initViews() {
        tvTitle = findViewById(R.id.tvTitle);
        btnSubmitTask = findViewById(R.id.btnSubmit);
        imageViewHeader = findViewById(R.id.imageViewHeader);
        cbTaskCompleted = findViewById(R.id.cbTerms);
        rgTaskType = findViewById(R.id.rgOptions);
        progressBarTaskProgress = findViewById(R.id.progressBar);
        ratingBarTaskPriority = findViewById(R.id.ratingBar);
        spinnerTaskCategories = findViewById(R.id.spinnerCategories);
        cardViewInfo = findViewById(R.id.cardViewInfo);
        tvCardTitle = findViewById(R.id.tvCardTitle);
        tvCardContent = findViewById(R.id.tvCardContent);
        tableLayoutSummary = findViewById(R.id.tableLayoutSummary);
        recyclerViewTasks = findViewById(R.id.recyclerViewItems);
    }

    // Configurar Spinner
    private void setupTaskSpinner() {
        ArrayList<String> categories = new ArrayList<>();
        categories.add("Trabajo");
        categories.add("Personal");
        categories.add("Estudios");
        categories.add("Casa");
        categories.add("Proyectos");
        categories.add("Urgente");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTaskCategories.setAdapter(adapter);
    }

    // Configurar RecyclerView
    private void setupRecyclerViewTasks() {
        tasksListData = new ArrayList<>();
        taskAdapter = new TaskAdapter(tasksListData);
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewTasks.setAdapter(taskAdapter);
    }

    // Configurar listeners
    private void setupListeners() {
        ratingBarTaskPriority.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            if (fromUser) {
                progressBarTaskProgress.setProgress((int) (rating * 20));
            }
        });

        btnSubmitTask.setOnClickListener(v -> addNewTaskFromInputs());

        cardViewInfo.setOnClickListener(v ->
                Toast.makeText(MainActivity.this,
                        tvCardContent.getText(), Toast.LENGTH_LONG).show());
    }

    // Crear una nueva tarea
    private void addNewTaskFromInputs() {

        String taskName = "Nueva tarea";

        boolean isCompleted = cbTaskCompleted.isChecked();

        // Tipo de tarea (RadioGroup)
        String taskType = "";
        int selectedRadioId = rgTaskType.getCheckedRadioButtonId();
        if (selectedRadioId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedRadioId);
            taskType = selectedRadioButton.getText().toString().trim();
        } else {
            Toast.makeText(this, "Selecciona un tipo de tarea", Toast.LENGTH_SHORT).show();
            return;
        }

        float priorityRating = ratingBarTaskPriority.getRating();
        String category = spinnerTaskCategories.getSelectedItem().toString();

        String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        String priorityText;
        if (priorityRating <= 1.5) priorityText = "Baja";
        else if (priorityRating <= 3.5) priorityText = "Media";
        else priorityText = "Muy importante";

        String tareaFinal = taskName + (isCompleted ? " (Completada)" : "");

        // Añadir a tabla
        addRowToTable(currentTime, currentDate, priorityText, category, tareaFinal);

        // Añadir a RecyclerView
        String recyclerTaskDescription = tareaFinal + " (" + category + ") - Tipo: " + taskType + " - Prioridad: " + priorityText;
        tasksListData.add(new TaskItem(recyclerTaskDescription, R.mipmap.ic_launcher));
        taskAdapter.notifyItemInserted(tasksListData.size() - 1);
        recyclerViewTasks.scrollToPosition(tasksListData.size() - 1);

        Toast.makeText(this, "Tarea añadida", Toast.LENGTH_SHORT).show();
        Log.d("TaskMaster", "Tarea: " + tareaFinal + ", Tipo: " + taskType +
                ", Prioridad: " + priorityRating + ", Categoría: " + category);
    }

    // Agregar fila a la tabla resumen
    private void addRowToTable(String hora, String fecha, String importancia, String categoria, String tarea) {
        TableRow row = new TableRow(this);

        row.addView(createCell(hora));
        row.addView(createCell(fecha));
        row.addView(createCell(importancia));
        row.addView(createCell(categoria));
        row.addView(createCell(tarea));

        tableLayoutSummary.addView(row);
    }

    // Crear celda para tabla
    private TextView createCell(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setPadding(8, 8, 8, 8);
        return tv;
    }
}
