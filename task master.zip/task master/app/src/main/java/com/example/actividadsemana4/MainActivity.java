package com.example.miapp;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CalendarView calendarView;
    ProgressBar progressBar;
    RatingBar ratingBar;
    SeekBar seekBar, seekBarDiscrete;
    TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendarView = findViewById(R.id.calendarView);
        progressBar = findViewById(R.id.progressBar);
        ratingBar = findViewById(R.id.ratingBar);
        seekBar = findViewById(R.id.seekBar);
        seekBarDiscrete = findViewById(R.id.seekBarDiscrete);
        tableLayout = findViewById(R.id.tableLayout);

        // Ejemplo de interacción: actualizar progreso con SeekBar
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                               @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                                                   progressBar.setProgress(progress);
                                               }
                                               @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                                               @Override public void onStopTrackingTouch(SeekBar seekBar) {}
                                           }

        );

        // Ejemplo: añadir fila dinámica
        addRow("Carlos", "06/09/2025", "Presente");
    }

    private void addRow(String nombre, String fecha, String estado) {
        TableRow row = new TableRow(this);
        row.addView(createCell(nombre));
        row.addView(createCell(fecha));
        row.addView(createCell(estado));
        tableLayout.addView(row);
    }

    private TextView createCell(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setPadding(8, 8, 8, 8);
        return tv;
    }
}
package com.example.miapp;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CalendarView calendarView;
    ProgressBar progressBar;
    RatingBar ratingBar;
    SeekBar seekBar, seekBarDiscrete;
    TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendarView = findViewById(R.id.calendarView);
        progressBar = findViewById(R.id.progressBar);
        ratingBar = findViewById(R.id.ratingBar);
        seekBar = findViewById(R.id.seekBar);
        seekBarDiscrete = findViewById(R.id.seekBarDiscrete);
        tableLayout = findViewById(R.id.tableLayout);

        // Ejemplo de interacción: actualizar progreso con SeekBar
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                               @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                                                   progressBar.setProgress(progress);
                                               }
                                               @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                                               @Override public void onStopTrackingTouch(SeekBar seekBar) {}
                                           }

        );

        // Ejemplo: añadir fila dinámica
        addRow("Carlos", "06/09/2025", "Presente");
    }

    private void addRow(String nombre, String fecha, String estado) {
        TableRow row = new TableRow(this);
        row.addView(createCell(nombre));
        row.addView(createCell(fecha));
        row.addView(createCell(estado));
        tableLayout.addView(row);
    }

    private TextView createCell(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setPadding(8, 8, 8, 8);
        return tv;
    }
}
